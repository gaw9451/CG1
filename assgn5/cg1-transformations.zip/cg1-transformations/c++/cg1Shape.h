/**
 * Header file for routines to be supplied by students
 *
 * Students should not modify this file
 */

#ifndef __shapes__
#define __shapes__

void makeDefaultShape ();


#endif