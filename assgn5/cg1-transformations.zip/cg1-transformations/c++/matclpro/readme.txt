Matrix TCL Pro 2.2
Copyright (c) 2000-2011 Techsoft
--------------------------------

This matrix template class library can be used in C++ programs for performing matrix operations easily and efficiently.  This professional version of Matrix TCL library supports most of the matrix operations. Please see the index.htm file under "DOC" directory for detail documentation of Matrix TCL Pro for installation, testing and usage. Also, you must read and agree to the license agreement included with this package, please see the license.txt file, before starting to use this software product.

This library may be used with any ANSI/ISO C++ compatible compilers under any operating systems.

TechSoft
Web: http://www.techsoftpl.com/matrix/
